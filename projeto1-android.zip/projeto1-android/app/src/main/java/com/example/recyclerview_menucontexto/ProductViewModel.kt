package com.example.recyclerview_menucontexto

import androidx.lifecycle.ViewModel

class ProductViewModel : ViewModel() {

    fun getProducts() = mutableListOf(
        Product(
            urlImage = "https://t4.ftcdn.net/jpg/06/93/09/47/240_F_693094707_Eavnydwp6Su2Tx9REPzSZxDmEbElu0Az.jpg",
            name = "Laranja",
            price = "199.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://t4.ftcdn.net/jpg/04/13/50/15/240_F_413501576_JBNFcI7nQ34BYAu7FXJTWLZQ8Y7ptSz3.jpg",
            name = "Creme",
            price = "129.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://t3.ftcdn.net/jpg/04/91/00/82/240_F_491008206_6J87meZRmjPYlrTpBEeVzFSm1m3kqOd2.jpg",
            name = "Telefone",
            price = "17.90".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1589188359593-0d5574c34f05",
            name = "Laptop",
            price = "999.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1603791440384-56cd371ee9b1",
            name = "Headphones",
            price = "299.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1593642532400-2682810df593",
            name = "Monitor",
            price = "199.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1512446756612-8fc1a25b3d9b",
            name = "Mouse",
            price = "49.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1608227493073-d82a8f74e7e4",
            name = "Teclado",
            price = "89.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1591186420507-9409b4c324f8",
            name = "Smartwatch",
            price = "149.00".convertToMoneyWithSymbol()
        ),
        Product(
            urlImage = "https://images.unsplash.com/photo-1605264374566-10d8b6b0ec12",
            name = "Câmera",
            price = "599.00".convertToMoneyWithSymbol()
        )
    )
}
